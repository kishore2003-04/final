import React from 'react';
function GrievanceForm() {
    return (
        <div className="tab-pane" id="submit-grievance" role="tabpanel" aria-labelledby="submit-tab">
            <h2 className="my-4">Submit Your Grievance</h2>
            <form action="/submit-grievance" method="POST" className="bg-light p-4 rounded shadow-sm">
                <div className="mb-3">
                    <label htmlFor="name" className="form-label">Your Name:</label>
                    <input type="text" className="form-control" id="name" name="name" required/>
                </div>

                <div className="mb-3">
                    <label htmlFor="email" className="form-label">Your Email:</label>
                    <input type="email" className="form-control" id="email" name="email" required/>
                </div>

                <div className="mb-3">
                    <label htmlFor="grievance-description" className="form-label">Grievance Description:</label>
                    <textarea className="form-control" id="grievance-description" name="grievance-description" rows="4"
                              required></textarea>
                </div>

                <div className="mb-3">
                    <label htmlFor="department" className="form-label">Select Department:</label>
                    <select className="form-select" id="department" name="department" required>
                        <option value="Public Transport">Public Transport</option>
                        <option value="Public Welfare">Public Welfare</option>
                        <option value="Tamilnadu Electric Board">Tamilnadu Electric Board</option>
                        <option value="Water Board">Water Board</option>
                        <option value="TN Education Department">TN Education Department</option>
                        <option value="I don't know">I don't know</option>
                    </select>
                </div>

                <div className="mb-3">
                    <label htmlFor="village" className="form-label">Village/Taluk:</label>
                    <select className="form-select" id="village" name="village" required>
                        <option value="Village1">Village 1</option>
                        <option value="Village2">Village 2</option>
                        <option value="Taluk1">Taluk 1</option>
                        <option value="Taluk2">Taluk 2</option>
                    </select>
                </div>

                <div className="mb-3">
                    <label htmlFor="city" className="form-label">City:</label>
                    <select className="form-select" id="city" name="city" required>
                        <option value="Chennai">Chennai</option>
                        <option value="Madurai">Madurai</option>
                        <option value="Coimbatore">Coimbatore</option>
                        <option value="Salem">Salem</option>
                    </select>
                </div>

                <div className="mb-3">
                    <label htmlFor="district" className="form-label">District:</label>
                    <select className="form-select" id="district" name="district" required>
                        <option value="Chennai">Chennai</option>
                        <option value="Madurai">Madurai</option>
                        <option value="Coimbatore">Coimbatore</option>
                        <option value="Salem">Salem</option>
                    </select>
                </div>

                <button type="submit" className="btn btn-primary">Submit Grievance</button>
            </form>
        </div>

    );
}

export default GrievanceForm;
