import React from 'react';
function Home() {
    return (
    <div>Home Page - Insert Code</div>
    );
}

export default Home;
