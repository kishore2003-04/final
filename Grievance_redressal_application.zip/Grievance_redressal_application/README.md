# Grievance Redressal React App
A simple React application for submitting and tracking grievances.
